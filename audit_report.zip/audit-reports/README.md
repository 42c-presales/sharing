# Security Audit Summary Report Generator

This script generates summary report across all APIs in an organization or its particular collection. It can help companies quickly assess the state of API security in the company or a particular project, and communicate the value of API Security and 42Crunch to stakeholders.

# Prerequisites

## 1. Upload OpenAPI files to the 42Crunch platform 

If there are multiple files that you need to discovered from a local repository, you can use the [42c-discovery.py](https://github.com/42c-presales/python-scripts/blob/master/42c-discovery.py) script to do that.

## 2. Download required libraries to your computer

If your computer does not have some of the Python libraries that this script needs, install them:

```python
python -m pip install chevron
```

## 3. Connect to the 42Crunch platform 

1. Click the drop down by your name in the top right corner
2. Go to Settings / API Tokens
3. Create new token with the following rights:
- API Contract Security Audit
- List resources
4. In the script code, paste that API token as the value of the api_token variable.

## 4. Other script parameters 

### PlatformURL
https://platform.42crunch.com, https://us.42crunch.cloud, etc.

### Severity
Select between critical, high, or medium to give a lower bound of the issues you want to display. For example, if you select critical, you will see only critical issues, but if you choose medium, you will see medium and all more important issues (critical and high). Also you can leave it without value to only display the errors but without the description tables.

### ClientEmail
The client email that will be displayed at the beginning of the report document.

### ReportName
Report file name (must end in html).

### ApisLimitation and MaxApisToAudit
Set apisLimitation value to true, and when the script reaches maxApisToAudit value will stop and create the report.

### DelayTime
The delay between calls in seconds (0 to no delay), will prevent problems when dealing with a large amount of APIs and a platform that is not prepared to work with a significant workload.

### RetryTimes
Amount times to retry in case of an error. 

### AbortIfError
If true and the program has an error during the execution, it will abort and create the report with the information until the moment of error.

### differentiate_by_version
If true it will differentiate between v2 and v3 versions, in cases with a big amount of issues it can be interesting to set it to false to reduce the amount of issues and the report size.

### links_file_name
A JSON file where the script will store the links of the issues that were found during the execution of the script.

# Usage
1. Run the script. Without any parameters, it will generate a report across all APIs in the organization. If you want to only target a particular collection - give that collection name as a command-line argument.
2. Open the HTML file. It might take time for the graphics to load.
3. If saving to PDF, make sure to select the **Background graphics** checkbox.
