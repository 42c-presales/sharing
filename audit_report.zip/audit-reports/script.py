import requests
import sys
import base64
import json
import sys
import chevron
from datetime import datetime
from collections import OrderedDict
from time import sleep

import htmlTemplates

#-----------------------------CONFIGURATION----------------------------#
docs_endpoint = "https://docs.42crunch.com"
links_file_name = "links.json"

platformURL = "https://us.42crunch.cloud"
api_token = ""

severity = "medium" #critical, high, medium or none

differentiate_by_version = False

clientEmail = "exampleClient@gmail.com"
reportName = "report.html" #must end in html

apisLimitation = False 
maxApisToAudit = 10

delayTime = 0.2 #delay between calls in seconds (0 to no delay)
retryTimes = 2

abortIfError = False #stop the execution and create the report with the collected info or continue 
#----------------------------------------------------------------------#

links_dict = {} #key: issueName, value:link

criticalIssues = {}
highIssues = {}
mediumIssues = {}
apisPerIssue = {} #list of apis per issue
dictWithReportInfo = {} #hashmap for chevron

#chart values
invalidApis = 0
apisWithCritical = 0
apisWithHigh = 0
apisWithMedium = 0
apisWithLow = 0
apisWithNoIssues = 0

#new chart values
highQualityApis = 0 #score between [100-75]
needImprovementApis = 0 #score between [75-50]
poorQualityApis = 0 #score between [50-1]
notOpenAPIStandardApis = 0 #score between [0-invalid]

invalid_api_descr = "The API contract file does not fully follow the requirements of the OpenAPI Specification standard and thus could not be properly audited."

def retrieveCollectionIdWithName (collection_name, token):
  url = platformURL + "/api/v2/collections?listOption=ALL&perPage=0"

  headers = {"accept": "application/json",
           "X-API-KEY": token}
  r = requests.get(url, headers=headers)

  if r.status_code != 200:
    print ("Can't list collections")
    print(f"failed with status code {r.status_code}") 
    sys.exit()
  
  target_collection_id = ""
  for c in r.json()['list']:
      if c['desc']['name'] == collection_name: #find a match in the collection name
          target_collection_id = c['desc']['id']
          break
  
  return [target_collection_id]

def retrieveCollectionIdsForOrganization(token):
  url = platformURL + "/api/v2/collections?listOption=ALL&perPage=0"

  headers = {"accept": "application/json",
           "X-API-KEY": token}
  r = requests.get(url, headers=headers)

  if r.status_code != 200:
    print ("Can't list collections")
    print(f"failed with status code {r.status_code}") 
    sys.exit()

  colIDs = [] # return a list of collections
  for col in r.json()['list']:
    colIDs.append(col["desc"]["id"])

  return colIDs

def retrieveApiKeys(cid, token): #from collection
  url = platformURL + "/api/v1/collections/" + cid + "/apis"

  headers = {"accept": "application/json",
           "X-API-KEY": token}
  r = requests.get(url, headers=headers)

  if r.status_code != 200:
    print ("Can't list collections or collection not found")
    print(f"failed with status code {r.status_code}") 
    sys.exit()
  
  apiIds = []
  for api in r.json()['list']: #iterate over all apis
      apiIds.append((api['desc']['id'], api['desc']['name'])) #append a tuple with id and name
  
  return apiIds

def get_report(api_id, token, api_name):
    global apisWithCritical
    global apisWithHigh
    global apisWithMedium
    global apisWithLow
    global apisWithNoIssues
    global invalidApis
    global apisPerIssue

    hasCritical = False
    hasHigh = False
    hasMedium = False
    hasLow = False
    hasInvalid = False

    CriticalIssuesDict = {}
    HighIssuesDict = {}
    MediumIssuesDict = {}

    url = f"{platformURL}/api/v1/apis/{api_id}/assessmentreport"
    headers = {"accept": "application/json",
            "X-API-KEY": token}

    r = requests.get(url, headers=headers)

    if r.status_code != 200:
        raise NameError(f"GET /assessmentreport {r.status_code}")

    report = r.json()
  
    # ---- Process the report -------------------------
    try:
      details = json.loads(base64.decodebytes(report["data"].encode("utf-8")))

      if details['valid'] == False: #invalid api
        hasInvalid = True
        invalidApis = invalidApis + 1
        iss = 'invalid-api'
        CriticalIssuesDict[iss] = (1, invalid_api_descr, "other")
        if not iss+"-critical" in apisPerIssue:
            apisPerIssue[iss+"-critical"] = [(api_id, api_name)]
        elif not api_name in apisPerIssue[iss+"-critical"]:
            apisPerIssue[iss+"-critical"].append((api_id, api_name))
      
      if "security" in details:
          for iss in details["security"]["issues"]:
                if not differentiate_by_version:
                  issWithoutV3prefix = iss.replace("v3-", "")
                else:
                  issWithoutV3prefix = iss
                criticality = details["security"]["issues"][iss]['criticality']
                if criticality == 2 and not hasLow:
                  hasLow = True
                  apisWithLow = apisWithLow+1
                if criticality == 3:
                  if not hasMedium:
                    hasMedium = True
                    apisWithMedium = apisWithMedium+1
                  if not issWithoutV3prefix in MediumIssuesDict:
                      MediumIssuesDict[issWithoutV3prefix] = (len(details["security"]["issues"][iss]["issues"]), details["security"]["issues"][iss]['description'], "security")
                  if not issWithoutV3prefix+"-medium" in apisPerIssue:
                    apisPerIssue[issWithoutV3prefix+"-medium"] = [(api_id, api_name)]
                  elif not api_name in apisPerIssue[issWithoutV3prefix+"-medium"]:
                    apisPerIssue[issWithoutV3prefix+"-medium"].append((api_id, api_name))
                if criticality == 4:
                  if not hasHigh:
                    hasHigh = True
                    apisWithHigh = apisWithHigh+1
                  if not issWithoutV3prefix in HighIssuesDict:
                      HighIssuesDict[issWithoutV3prefix] = (len(details["security"]["issues"][iss]["issues"]), details["security"]["issues"][iss]['description'], "security")
                  if not issWithoutV3prefix+"-high" in apisPerIssue:
                    apisPerIssue[issWithoutV3prefix+"-high"] = [(api_id, api_name)]
                  elif not api_name in apisPerIssue[issWithoutV3prefix+"-high"]:
                    apisPerIssue[issWithoutV3prefix+"-high"].append((api_id, api_name))
                if criticality == 5:
                    if not hasCritical:
                      hasCritical = True
                      apisWithCritical = apisWithCritical + 1
                    if not issWithoutV3prefix in CriticalIssuesDict:
                        CriticalIssuesDict[issWithoutV3prefix] = (len(details["security"]["issues"][iss]["issues"]), details["security"]["issues"][iss]['description'], "security")
                    if not issWithoutV3prefix+"-critical" in apisPerIssue:
                      apisPerIssue[issWithoutV3prefix+"-critical"] = [(api_id, api_name)]
                    elif not api_name in apisPerIssue[issWithoutV3prefix+"-critical"]:
                      apisPerIssue[issWithoutV3prefix+"-critical"].append((api_id, api_name))
             
      if "data" in details:
          for iss in details["data"]["issues"]:
                if not differentiate_by_version:
                  issWithoutV3prefix = iss.replace("v3-", "")
                else:
                  issWithoutV3prefix = iss
                criticality = details["data"]["issues"][iss]['criticality']
                if criticality == 2 and not hasLow:
                  hasLow = True
                  apisWithLow = apisWithLow+1
                if criticality == 3:
                  if not hasMedium:
                    hasMedium = True
                    apisWithMedium = apisWithMedium+1
                  if not issWithoutV3prefix in MediumIssuesDict:
                      MediumIssuesDict[issWithoutV3prefix] = (len(details["data"]["issues"][iss]["issues"]), details["data"]["issues"][iss]['description'], "data")
                  if not issWithoutV3prefix+"-medium" in apisPerIssue:
                    apisPerIssue[issWithoutV3prefix+"-medium"] = [(api_id, api_name)]
                  elif not api_name in apisPerIssue[issWithoutV3prefix+"-medium"]:
                    apisPerIssue[issWithoutV3prefix+"-medium"].append((api_id, api_name))
                if criticality == 4:
                  if not hasHigh:
                    hasHigh = True
                    apisWithHigh = apisWithHigh+1
                  if not issWithoutV3prefix in HighIssuesDict:
                      HighIssuesDict[issWithoutV3prefix] = (len(details["data"]["issues"][iss]["issues"]), details["data"]["issues"][iss]['description'], "data")
                  if not issWithoutV3prefix+"-high" in apisPerIssue:
                    apisPerIssue[issWithoutV3prefix+"-high"] = [(api_id, api_name)]
                  elif not api_name in apisPerIssue[issWithoutV3prefix+"-high"]:
                    apisPerIssue[issWithoutV3prefix+"-high"].append((api_id, api_name))
                if criticality == 5:
                    if not hasCritical:
                      hasCritical = True
                      apisWithCritical = apisWithCritical + 1
                    if not issWithoutV3prefix in CriticalIssuesDict:
                        CriticalIssuesDict[issWithoutV3prefix] = (len(details["data"]["issues"][iss]["issues"]), details["data"]["issues"][iss]['description'], "data")
                    if not issWithoutV3prefix+"-critical" in apisPerIssue:
                      apisPerIssue[issWithoutV3prefix+"-critical"] = [(api_id, api_name)]
                    elif not api_name in apisPerIssue[issWithoutV3prefix+"-critical"]:
                      apisPerIssue[issWithoutV3prefix+"-critical"].append((api_id, api_name))
      
      if not hasInvalid and not hasCritical and not hasMedium and not hasHigh and not hasLow:
        apisWithNoIssues = apisWithNoIssues + 1
      return details["score"],CriticalIssuesDict, HighIssuesDict, MediumIssuesDict
    except:
      #the api is invalid to audit
      iss = 'invalid-api'
      CriticalIssuesDict[iss] = (1, invalid_api_descr, "other")
      if not iss+"-critical" in apisPerIssue:
          apisPerIssue[iss+"-critical"] = [(api_id, api_name)]
      elif not api_name in apisPerIssue[iss+"-critical"]:
          apisPerIssue[iss+"-critical"].append((api_id, api_name))
      return 0,CriticalIssuesDict, HighIssuesDict, MediumIssuesDict

def saveReport():
    try:
        with open('./templateReport.html', 'r') as f:
            report =  chevron.render(f, dictWithReportInfo) # use chevron lib and the dict
            f = open(reportName, "w")
            f.write(report)
            f.close()
    except IOError: 
        print("Error, unable to open template report file")
        sys.exit()
    print("Report dumped successfully")

def getPriorityIssuesSchemaInd(name, value):
    # for the priority issues chart
    sch = htmlTemplates.priorityIssuesSchema.replace("issue_name", name)
    sch = sch.replace("issue_value", str(value))
    return sch

def getPriorityIssuesSchemaDouble(name1, value1, name2, value2):
    # for the priority issues chart
    sch = htmlTemplates.priorityIssuesSchemaDouble.replace("issue_name1", name1)
    sch = sch.replace("issue_value1", str(value1))
    sch = sch.replace("issue_name2", name2)
    sch = sch.replace("issue_value2", str(value2))
    return sch

def getPriorityIssueDescription(name, amount, severity, description, issueType):
    # for the descriptions charts
    sch = htmlTemplates.priorityIssueDescription.replace("issue_name", name)
    sch = sch.replace("amount_issues", str(amount))
    sch = sch.replace("issue_severity", severity)

    if int(amount) > 20: #set the limit of the list to 20
      sch = sch.replace("amount_seeing", "20")
      sch = sch.replace("issue_limitation", htmlTemplates.IssueLimitValueDescr)
    else:
      sch = sch.replace("amount_seeing", str(amount))
      sch = sch.replace("issue_limitation", "")

    sch = sch.replace("issue_description", description)
    link = getIssueLink(name, issueType)
    if link == "": # if url is empty
      if name != "invalid-api":
        print("Warning: url for the issue: " + name + " not found")
        sch = sch.replace(htmlTemplates.LinkHeader, htmlTemplates.NoLinkHeader) # delete url code
      else:
        sch = sch.replace(htmlTemplates.LinkHeader, "") # delete url code

    sch = sch.replace("docs_url", link)
    
    examples = ""
    for i in range (len(apisPerIssue[name+"-"+severity])): #add apis with that crit error
      if i >=20: 
        break
      examples = examples + getIssueListEntry(apisPerIssue[name+"-"+severity][i][1], apisPerIssue[name+"-"+severity][i][0])

    sch = sch.replace("issue_list", examples)
    return sch

def getIssueLink(name, issueType):
    global links_dict
    if name in links_dict:
      return links_dict[name]

    oasV = "oasv2" #oas2 or 3
    if name.startswith("v3") and differentiate_by_version:
      oasV = "oasv3"

    # two types -> security or data
    if issueType == "data":
      l = get_data_iss_url(name, oasV)
      links_dict[name] = l
      return l
    elif issueType == "security":
      l = get_security_iss_url(name, oasV)
      links_dict[name] = l
      return l
    else:
      return ""
  
def get_data_iss_url(iss, oasVersion):
    dataOptions = ["parameters", "responsedefinition", "responseheader", "schema"]
    # search using the data options
    for op in dataOptions: 
        url = f"{docs_endpoint}/latest/content/{oasVersion}/datavalidation/{op}/{iss}.htm"
        r = requests.get(url)
        if r.status_code == 200:
            return url
    return ""

def get_security_iss_url(iss, oasVersion):
    secOptions = ["authentication", "authorization", "transport"]
    # search using the security options
    for op in secOptions:
        url = f"{docs_endpoint}/latest/content/{oasVersion}/security/{op}/{iss}.htm"
        r = requests.get(url)
        if r.status_code == 200:
            return url
    return ""

def getIssueListEntry(name, id):
  sch = htmlTemplates.IssueListEntry.replace("api_name", name)
  link = platformURL+"/apis/"+id+"/security-audit-report"
  linkHtml = """ <a href=" """ + link + """ "> """ + "View detailed report" + """</a>"""
  sch = sch.replace("api_route", linkHtml)
  return sch

def getPerc( amount, total): #return % from two values
  res = float(amount)/float(total)*100.0
  return str(int(res))+'%'

def load_json_links():
  global links_dict
  try:
    with open(links_file_name, encoding='utf-8') as json_file:
        links_dict = json.load(json_file)
  except IOError: 
        print("Error, unable to open links file")
        sys.exit()
  print("loaded")

def save_json_links():
  with open(links_file_name, 'w') as f:
    json.dump(links_dict, f)

def get_Issues_table(issuesList, category):   
        issSchema = ""   
        if len(issuesList)%2 == 0:
            i=0
            j=int(len(issuesList)/2)
            while i < len(issuesList)/2:
                issSchema = issSchema + getPriorityIssuesSchemaDouble(issuesList[i][0], issuesList[i][1][0], issuesList[j][0], issuesList[j][1][0])
                i = i + 1
                j = j + 1
        else:
            i=0
            j=int((len(issuesList))/2)+1
            while i < (len(issuesList)/2)-1:
                issSchema = issSchema + getPriorityIssuesSchemaDouble(issuesList[i][0], issuesList[i][1][0], issuesList[j][0], issuesList[j][1][0])
                i = i + 1
                j = j + 1
            issSchema = issSchema + getPriorityIssuesSchemaInd(issuesList[int((len(issuesList)-1)/2)][0], issuesList[int((len(issuesList)-1)/2)][1][0]) #TODO: no testeado
        

        table = htmlTemplates.IssueTable
        issueNameLower = category
        issueNameUpper = category.capitalize() #upper first letter
        table = table.replace("nameLower", issueNameLower)
        table = table.replace("nameUpper", issueNameUpper)
        table = table.replace("tableContent", issSchema)

        return table

def get_Issues_description_table(issuesList, category):
    issuesDescription = ""
    for issue in issuesList:
        issuesDescription = issuesDescription + getPriorityIssueDescription(issue[0], issue[1][0], category, issue[1][1], issue[1][2])
    return issuesDescription

def dict_to_list(dictt):
  # convert to list and sort it by number of errors
  listt = list(OrderedDict(sorted(dictt.items(), key=lambda t: t[1])).items())[::-1]
  for i in range(len(listt)):
    listt[i] = (listt[i][0], listt[i][1])
  return listt

def main():
    global highQualityApis
    global needImprovementApis
    global poorQualityApis
    global notOpenAPIStandardApis

    a = datetime.now() # start counting
    
    load_json_links() #load json links dict

    collection_name = ""
    if len(sys.argv) > 1:
        collection_name = sys.argv[1]
        print("Retrieving from collection...")
    else:
        print("Retrieving from organization...")

    if collection_name != "": #retrieve colIds from a colName or a organization
        colIds = retrieveCollectionIdWithName(collection_name, api_token)
    else:
        colIds = retrieveCollectionIdsForOrganization(api_token)
   
    apis = [] #list of apis to audit
    for colId in colIds:
       keys = retrieveApiKeys(colId, api_token) #get api keys from a the list of collections
       apis = apis + keys
       sleep(delayTime)
    
    print("Auditing the following apis:")
    apisAudited = 0
    for api in apis: #iterate over all apis
        if apisLimitation and apisAudited >= maxApisToAudit: #break in case apis limitation
            print("Api limit reached") 
            break
        print("Api name:", api[1], "Id:", api[0])

        resValid = False
        for i in range(0,retryTimes+1):
          try:
            score, criticalIss, highIss, mediumIss = get_report(api[0], api_token, api[1]) #get report
            resValid = True
          except:
            print("Exception occurred in api", api[0])
            sleep(delayTime)
          else:
            break
        if not resValid and abortIfError:
          print("ERROR: The scans cannot be completed, creating the report with the information obtained so far")
          break
        if not resValid:
          print("ERROR: The api cannot be audited, skipping")
          continue
        
        # give a quality to the api
        if score >= 75:
          highQualityApis = highQualityApis + 1
        elif score >=50:
          needImprovementApis = needImprovementApis + 1
        elif score >0:
          poorQualityApis = poorQualityApis + 1
        else:
          notOpenAPIStandardApis = notOpenAPIStandardApis + 1

        for issue in criticalIss: #count issues
          if issue in criticalIssues:
              criticalIssues[issue] = (criticalIssues[issue][0] + 1, criticalIssues[issue][1], criticalIssues[issue][2])
          else:
              criticalIssues[issue] = (1 ,criticalIss[issue][1], criticalIss[issue][2])
      
        for issue in highIss: 
          if issue in highIssues:
              highIssues[issue] = (highIssues[issue][0] + 1, highIssues[issue][1], highIssues[issue][2])
          else:
              highIssues[issue] = (1 ,highIss[issue][1], highIss[issue][2])

        for issue in mediumIss: 
          if issue in mediumIssues:
              mediumIssues[issue] = (mediumIssues[issue][0] + 1, mediumIssues[issue][1], mediumIssues[issue][2])
          else:
              mediumIssues[issue] = (1 ,mediumIss[issue][1], mediumIss[issue][2])

        apisAudited = apisAudited + 1
        sleep(delayTime)

    print("Preparing report...")

    totalFiles = apisAudited
    dictWithReportInfo['createdOn'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    dictWithReportInfo['clientEmail'] = clientEmail
    dictWithReportInfo['totalAuditedFiles'] = totalFiles
    dictWithReportInfo['invalidApis'] = invalidApis
    dictWithReportInfo['invalidApisP'] = getPerc(invalidApis,totalFiles)
    dictWithReportInfo['criticalApis'] = apisWithCritical
    dictWithReportInfo['criticalApisP'] = getPerc(apisWithCritical,totalFiles)
    dictWithReportInfo['highApis'] = apisWithHigh
    dictWithReportInfo['highApisP'] = getPerc(apisWithHigh,totalFiles)
    dictWithReportInfo['mediumApis'] = apisWithMedium
    dictWithReportInfo['mediumApisP'] = getPerc(apisWithMedium,totalFiles)
    dictWithReportInfo['lowApis'] = apisWithLow
    dictWithReportInfo['lowApisP'] = getPerc(apisWithLow,totalFiles)
    dictWithReportInfo['noIssuesApis'] = apisWithNoIssues
    dictWithReportInfo['noIssuesApisP'] = getPerc(apisWithNoIssues,totalFiles)
    dictWithReportInfo['highQualityApis'] = highQualityApis
    dictWithReportInfo['highQualityApisP'] = getPerc(highQualityApis,totalFiles)
    dictWithReportInfo['needImprovementApis'] = needImprovementApis
    dictWithReportInfo['needImprovementApisP'] = getPerc(needImprovementApis,totalFiles)
    dictWithReportInfo['poorQualityApis'] = poorQualityApis
    dictWithReportInfo['poorQualityApisP'] = getPerc(poorQualityApis,totalFiles)
    dictWithReportInfo['notOpenAPIStandardApis'] = notOpenAPIStandardApis
    dictWithReportInfo['notOpenAPIStandardApisP'] = getPerc(notOpenAPIStandardApis,totalFiles)

    #convert to list and sort it by number of errors
    criticaldictlist = dict_to_list(criticalIssues)
    highDictlist = dict_to_list(highIssues)
    mediumDictlist = dict_to_list(mediumIssues)

    #create the tables with issues instances
    dictWithReportInfo['criticalIssues'] = get_Issues_table(criticaldictlist, "critical")
    dictWithReportInfo['highIssues'] = get_Issues_table(highDictlist, "high")
    dictWithReportInfo['mediumIssues'] = get_Issues_table(mediumDictlist, "medium")

    #depending on what the severity value is, create the issues descriptions 
    if severity == "medium":
      dictWithReportInfo['criticalIssuesDescription'] = get_Issues_description_table(criticaldictlist, "critical")
      dictWithReportInfo['highIssuesDescription'] = get_Issues_description_table(highDictlist, "high")    
      dictWithReportInfo['mediumIssuesDescription'] = get_Issues_description_table(mediumDictlist, "medium")
    elif severity == "high":
      dictWithReportInfo['criticalIssuesDescription'] = get_Issues_description_table(criticaldictlist, "critical")
      dictWithReportInfo['highIssuesDescription'] = get_Issues_description_table(highDictlist, "high")    
    elif severity == "critical":
      dictWithReportInfo['criticalIssuesDescription'] = get_Issues_description_table(criticaldictlist, "critical")

    saveReport() #dump report
    save_json_links() #save new links
    b = datetime.now()
    print("Time elapsed:",  (b-a).total_seconds())

main()