IssueTable = """
  <p></p>
  <div class="card">
		<div class="card-body p-4">
			<div class="d-flex justify-content-between">
				<a id="nameLowerDomain"></a>
				<h4><i class="fas fa-exclamation-circle"></i> nameUpper Priority Issues</h4>
			</div>
			<hr>
			<p class="font-weight-bold">nameUpper priority issues that were found include:</p>
			tableContent
		</div>
  </div> 
"""
priorityIssuesSchemaDouble = """
    <div class="row mt-3">
        <div class="col mr-2">
        <div class="d-flex justify-content-between">
            <div>
            <div class="d-flex justify-content-start"><i class="fas fa-circle pr-1 text-danger mt-1 mr-1"></i>
                <div>
                    <h6> issue_name1</h6>
                </div>
            </div>
            </div>
            <h6 class="text-danger width-maker">
                <a style="text-decoration: none; color:red;" href="#issue_name1">
                    issue_value1 instances
                </a>
            </h6>
        </div>
        </div>
        <div class="col ml-2">
        <div class="d-flex justify-content-between">
            <div>
            <div class="d-flex justify-content-start"><i class="fas fa-circle pr-1 text-danger mt-1 mr-1"></i>
                <div>
                    <h6> issue_name2</h6>
                </div>
            </div>
            </div>
            <h6 class="text-danger width-maker">
                <a style="text-decoration: none; color:red;" href="#issue_name2">
                    issue_value2 instances
                </a>
            </h6>
        </div>
        </div>
    </div> 
"""

priorityIssuesSchema = 	"""
    <div class="row mt-3">
        <div class="col mr-2">
        <div class="d-flex justify-content-between">
            <div>
            <div class="d-flex justify-content-start"><i class="fas fa-circle pr-1 text-danger mt-1 mr-1"></i>
                <div>
                    <h6> issue_name </h6>
                </div>
            </div>
            </div>
            
                <h6 class="text-danger width-maker">
                    <a style="text-decoration: none; color:red;" href="#issue_name">
                        issue_value instances
                    </a>
                </h6>
            
        </div>
        </div>
        <div class="col ml-2">
        <div class="d-flex justify-content-between">
        </div>
        </div>
    </div> 
"""

priorityIssueDescription = """
<div class="page mt-4">
    <div class="row mb-4">
        <div class="col-md-6"></div>
        <div class="col-md-6 text-right"><img src="img/logo_dark.png" width="380" height="49" alt=""/></div>
    </div>
    <div  class="card">
        <div class="card-body p-4">
            <div class="row">
                <a id="issue_name"></a>
                <div class="col-md-8">
                <h4><i class="fas fa-circle pr-1 text-danger mt-1 mr-1"></i> issue_name </h4>
                </div>
                <div class="col-md-4 text-right">
                <h4 class="font-weight-bold"><span class="text-danger">amount_issues</span> affected APIs</h4>
                </div>
            </div>
            <div class="graphic">	</div>
            <hr>
            <div class="row mt-0">
                <div class="col-5">
                <p class="font-weight-bold mb-2">Severity: <span class="text-danger">issue_severity</span></p>
                <p class="font-weight-bold mb-2">Description</p>
                <p>issue_description</p>
                <p class="mt-4">	<span class="font-weight-bold">More information on the issue can be found at:<p><a href="docs_url">docs_url</a></p></span>	</p>
                </div>
                <div class="col-7">
                <div class="mt-2 mb-4">
                    <p class="font-weight-bold mb-2">There are <span class="text-danger">amount_issues</span> affected APIs</p>
                </div>
                <div class="mt-4">
                    <div class="api-list">
                        <ul>
                            issue_list
                        </ul>
                    </div>
                    issue_limitation
                </div>
                </div>
            </div>
        </div>
    </div>
    </div>
"""

IssueLimitValueDescr = """
    <div class="alert alert-critical text-critical mb-0" role="alert">
    This report only lists the first 20 APIs with this issue. To get the full report contact a 42Crunch representative.
    </div>
"""

IssueListEntry = """
<li><span class="badge badge-secondary mr-2">api_name</span> api_route</li>
"""

LinkHeader = """<p class="mt-4">	<span class="font-weight-bold">More information on the issue can be found at:<p><a href="docs_url">docs_url</a></p></span>	</p>"""

NoLinkHeader = """ <p class="mt-4">	<span class="font-weight-bold">Warning: this issue is outdated. Audit the following API(s) again to get an updated report.</span>	</p> """